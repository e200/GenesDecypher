#include "constantes.h"

int registre_os_codons(
    char registro_de_amin_acidos[][MAX_CODON],
    char seq_amin_acid[],
    int qtd_amin_acidos,
    int num_tentativas
) {
    int
        byte = num_tentativas,
        con_while = 0;

    for (int i = 0; i < qtd_amin_acidos; i++)
    {
        while (con_while != 3)
        {
            registro_de_amin_acidos[i][con_while] = seq_amin_acid[byte];

            byte++;

            con_while++;
        }

        con_while = 0;
    }

    return 0;
}
