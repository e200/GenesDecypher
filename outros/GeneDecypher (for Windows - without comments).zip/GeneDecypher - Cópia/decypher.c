#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

#include "constantes.h"
#include "leitor_amostras.h"
#include "registra_codons.h"
#include "da_pra_tentar.h"

int main(int argc, char *argv[])
{
	int
        falhou,
        qtd_amin_acidos = 0,
         qtd_nucleotides = 0,
        num_tentativas = 0,
        cod_gen_decifrado = 0;

    char
        proteina[MAX_AMIN_ACID_NA_PROT],
        seq_amin_acidos[MAX_SEQ_GEN],
        registro_de_amin_acidos[MAX_AMIN_ACID_NA_PROT][MAX_CODON];
    
    char
        *amostra_proteina = argv[1],
        *amostra_sequencia_genetica = argv[2];
        
    setlocale(LC_ALL, "Portuguese");
    
    leia_amostra(
        amostra_proteina,
        proteina,
        &qtd_amin_acidos
    );

    leia_amostra(
        amostra_sequencia_genetica,
        seq_amin_acidos,
        &qtd_nucleotides
        );

    while (da_pra_tentar(
        cod_gen_decifrado,
        num_tentativas,
        qtd_nucleotides,
        qtd_amin_acidos
    ))
    {
        falhou = 0;

        registre_os_codons(
            registro_de_amin_acidos,
            seq_amin_acidos,
            qtd_amin_acidos,
            num_tentativas
        );
        
        for (int i = 0; i < qtd_amin_acidos; i++)
        {
            for (int j = 0; j <= qtd_amin_acidos; j++)
            {
                if (i != j)
                {
                    if (
                        registro_de_amin_acidos[i][0] == registro_de_amin_acidos[j][0]
                        &&
                        registro_de_amin_acidos[i][1] == registro_de_amin_acidos[j][1]
                        &&
                        registro_de_amin_acidos[i][2] == registro_de_amin_acidos[j][2]
                    ) {
                        falhou = 1;
                    }
                }

                if (falhou == 1)
                {
                    num_tentativas++;
					
                    printf("%d� tentativa: %c e %c s�o iguais -> ", num_tentativas, proteina[i], proteina[j]);
                    printf("%s == %s\n", registro_de_amin_acidos[i], registro_de_amin_acidos[j]);

                    break;
                }
            }

            if (falhou == 1)
            {
                break;
            }
        }
        
        if (falhou == 0)
        {
            printf("\nC�digo gen�tico decifrado!\n");
            printf("\nTotal de tentativas: %d\n", num_tentativas + 1);
            printf("C�digo gen�tico: ");

            for (int i = 0; i < qtd_amin_acidos; i++)
            {
                printf("%s", registro_de_amin_acidos[i]);
            }

            printf("\n");            

            break;
        }
    }

    if (falhou == 1)
    {
        printf("\nN�o foi poss�vel decifrar o c�digo gen�tico da prote�na:\n\n%s\n\n na sequ�ncia gen�tica dada.\n\n", proteina);            
    }

    return 0;
}
