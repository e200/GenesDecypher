int da_pra_tentar(
    int cod_gen_decifrado,
    int num_tentativas,
    int qtd_nucleotides,
    int qtd_amin_acidos
) {
    return (cod_gen_decifrado == 0) && (num_tentativas < (qtd_nucleotides - qtd_amin_acidos));
}
