#include <stdio.h>
#include <stdlib.h>

void leia_amostra(char nome_arquivo[], char *saida, int *num_bytes)
{
    FILE *ptr_ficheiro;

    ptr_ficheiro = fopen(nome_arquivo, "r");

    char byte;

    int i = 0;

    while ((byte = getc(ptr_ficheiro)) != EOF)
    {
        saida[i] = byte;
        
        i++;
    }

    fclose(ptr_ficheiro);
    
    *num_bytes = i;
}
