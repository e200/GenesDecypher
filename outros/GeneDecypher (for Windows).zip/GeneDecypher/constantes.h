/**
 * Limite m�ximo de amino �cidos
 * na nossa prote�na.
 */
#define MAX_AMIN_ACID_NA_PROT 1000

/**
 * Limite de cod�ns.
 */
#define MAX_CODON 4

/**
 * Limite de sequ�ncias gen�ticas.
 */
#define MAX_SEQ_GEN 10000
