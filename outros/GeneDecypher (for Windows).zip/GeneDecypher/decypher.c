/**
 * Este programa decifra o c�digo
 * gen�tico de um amino �cido em
 * uma prote�na.
 *
 * Para entender como ele funciona,
 * � extremamente recomend�vel entender
 * antes como o c�digo gen�tico funciona.
 *
 * Para facilitar a compreens�o de
 * quem venha a estudar esse c�digo,
 * preferi separar algumas coisas em
 * arquivos.
 *
 * Mas ainda assim o c�digo continua
 * um monstro.
 *
 * So, be careful...
 *
 * Data: 31/10/2017
 *
 * Autor: Eleandro Duzentos <eleandro@inbox.ru>
 * Reposit�rio: https://github.com/e200/GenesDecypher/blob/master/
 */
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/**
 * Cont�m as constantes necess�rias
 * para criarmos os vetores do decifrador.
 */
#include "constantes.h"

/**
 * Cont�m a fun��o que l� todos
 * os bytes dos arquivos que cont�m
 * as amostras necess�rias para
 * decifrar os c�digos gen�ticos dos
 * um amino �cidos.
 *
 * Estas amostras s�o: o arquivo que
 * cont�m a prote�na e o arquivo
 * que cont�m a sequ�ncia gen�tica.
 */
#include "leitor_amostras.h"

/**
 * Cont�m a fun��o que registra e
 * associa cada c�don ao seu respectivo
 * amino �cido.
 */
#include "registra_codons.h"

/**
 * Informa se ainda da pra tentar
 * decifrar os nossos amino �cidos.
 */
#include "da_pra_tentar.h"

/**
 * O par�metro `argc` indica o n�mero
 * de par�metros passados via terminal.
 *
 * O ponteiro `argv` aponta para o
 * par�metros passados via terminal.
 *
 * Vamos us�-los para pegar os nomes
 * das nossas amostras (ficheiros ).
 */
int main(int argc, char *argv[])
{
	int
        /**
         * Informa quando uma tentativa
         * dentro do loop de tentativas
         * falhou ou n�o.
         */
        falhou,

        /**
         * Quantidade de amino �cidos
         * encontrados na prote�na.
         */
        qtd_amin_acidos = 0,

        /**
         * Quantidade de nucle�tides
         * encontrados na sequ�ncia gen�tica.
         */
         qtd_nucleotides = 0,

        /**
         * N�mero de tentativas de decifrar
         * o c�digo gen�tico da prote�na dada.
         */
        num_tentativas = 0,

        /**
         * C�digo gen�tico decifrado?
         * 
         * Se 1, informa ao programa que
         * o c�digo gen�tico foi finalmente
         * decifrado.
         */
        cod_gen_decifrado = 0;

    char
        /**
         * Este vetor armazenar� a nossa
         * prote�na.
         */
        proteina[MAX_AMIN_ACID_NA_PROT],

        /**
         * Este vetor armazenar� a sequ�ncia
         * de amino �cidos.
         */
        seq_amin_acidos[MAX_SEQ_GEN],

        /**
         * Esta matr�z (ou vetor 2d) armazenar�
         * as sequ�ncias de amino �cidos achados
         * a cada tentativa.
         *
         * Que tentativa?
         *
         * Achar o c�digo gen�tico de um amino
         * �cido consiste em tenativa e erro,
         * tentar, errar e tentar de novo at�
         * achar ou at� n�o poder mais.
         *
         * S� com isso, se entenderes bem de l�gica
         * j� sabes que vai chover **loops**.
         * 
         * As linhas da nossa matr�z representar�o
         * os amino �cidos. As colunas (que armazenar�o
         * um limite de 3 elementos) representar�o
         * os c�digos gen�ticos que juntos formam
         * os cod�ns.
         * 
         * Ex:
         *
         * Fique atento:
         *
         * Isto � uma prote�na: MHISY.
         *
         * Cada letra dessa prote�na representa
         * um amino �cido.
         *
         * Cada amino �cido possui um c�don.
         *
         * Cada cod�n possui 3 nucleotide.
         *
         * Um nucleotide � representado pelas
         * letras {a, c, t, g}.
         *
         * Perceba tudo isso nessa tab�la: 
         * 
         *                col
         *
         *       | M | H | I | S | Y |     TODAS AS LETRAS FORMAM A PROTE�NA.
         * Lin   |agt|ttt|gga|aag|ata|     CADA LETRA TEM O SEU COD�N.
         * 
         * Lembrando que cada amino �cido
         * s� pode conter 3 letras (nucleotides)
         * no seu c�digo gen�tico.
         */
        registro_de_amin_acidos[MAX_AMIN_ACID_NA_PROT][MAX_CODON];
    
    /**
     * Pegando os ponteiros que apontam
     * para o caminho das amostras.
     * 
     * � aqui onde recebemos do terminal
     * os nomes dos arquivos contendo as
     * amostras.
     * 
     * O primeiro arquivo deve sempre ser
     * o que cont�m a amostra da prote�na,
     * o segundo deve conter a amostra da
     * sequ�ncia gen�tica.
     */
    char
        *amostra_proteina = argv[1],
        *amostra_sequencia_genetica = argv[2];
    
    /*
	 * Experimentem remover alguns c�digos
	 * para verem o que acontece.
	 */    
    setlocale(LC_ALL, "Portuguese");
    
    /**
     * Pegando a nossa amostra da prote�na.
     * 
     * Veja o arquivo: leitor_amostras.h
     */
    leia_amostra(
        amostra_proteina,
        proteina,
        &qtd_amin_acidos
    );

    /**
     * Pegando a nossa amostra da sequ�ncia gen�tica.
     * 
     * Veja o arquivo: leitor_amostras.h
     */
     leia_amostra(
        amostra_sequencia_genetica,
        seq_amin_acidos,
        &qtd_nucleotides
        );
        
    /**
     * At� aqui j� temos a nossa prote�na e
     * a nossa sequ�ncia gen�tica, � tudo que
     * que precisamos para fazer a nossa an�lize
     * e da� decifrar o c�digo gen�tico do nosso
     * amino �cido.
     *
     * Este `while` vai se executar at�
     * algu�m o dizer: para, o c�digo
     * gen�tico j� foi encontrado, ou
     * o n�o haver mais tentativas
     * poss�veis.
     */
    while (da_pra_tentar(
        cod_gen_decifrado,
        num_tentativas,
        qtd_nucleotides,
        qtd_amin_acidos
    ))
    {
        /**
         * Nova tentativa, ainda n�o sabemos
         * se ela falhar� ou n�o, ent�o
         * reiniciamos est� vari�vel.
         *
         * Caso est� tentativa falhe, algures
         * algu�m vai setar est� vari�vel com
         * o valor "1".
         */
        falhou = 0;

        /**
         * Vamos registrar os cod�ns dispon�veis.
         */
        registre_os_codons(
            registro_de_amin_acidos,
            seq_amin_acidos,
            qtd_amin_acidos,
            num_tentativas
        );

        /**
         * Ok, temos os nossos cod�ns registrados
         * e associados aos seus amino �cidos na
         * matr�z `registro_de_amin_acidos`.
         *
         * Agora vamos ver dentro do nosso registro
         * se h� alguma sequ�ncia de cod�ns repetidas,
         * se sim, o teste t� negativo (falhou), se n�o,
         * continuamos os nossos testes at� n�o encontrarmos
         * nenhuma sequ�ncia repetida.
         *
         * Se isso acontecer, deciframos o nosso c�digo
         * gen�tico ou os amino �cidos da nossa prote�na
         * acabaram kkkkkkkkkkkkkkk.
         *
         * Ok, vamos comparar o amino �cido `registro_de_amin_acidos[i]`
         * com os restantes, os restantes s�o todos os `registro_de_amin_acidos[j]`
         * diferentes do `registro_de_amin_acidos[i]`.
         */
        for (int i = 0; i < qtd_amin_acidos; i++)
        {
            // Percorrendo cada sequ�ncia de um amino �cido.
            for (int j = 0; j <= qtd_amin_acidos; j++)
            {
                /**
                 * Esta compara��o previne que o mesmo
                 * amino �cido seja comparado consigo
                 * mesmo.
                 */
                if (i != j)
                {
                    /**
                     * Aqui verificamos se os cod�ns
                     * dos amino �cidos a ser testados
                     * s�o iguais.
                     *
                     * Se sim, o teste falha.
                     */
                    if (
                        registro_de_amin_acidos[i][0] == registro_de_amin_acidos[j][0]
                        &&
                        registro_de_amin_acidos[i][1] == registro_de_amin_acidos[j][1]
                        &&
                        registro_de_amin_acidos[i][2] == registro_de_amin_acidos[j][2]
                    ) {
                        falhou = 1;
                    }
                }

                /**
                 * A tentativa falhou? cancele este loop.
                 * Diga em que amino �cido falhou e qual
                 * foi a combina��o.
                 */
                if (falhou == 1)
                {
                    // + Uma tentaiva falhada.
                    num_tentativas++;
					
                    printf("%d� tentativa: %c e %c s�o iguais -> ", num_tentativas, proteina[i], proteina[j]);
                    printf("%s == %s\n", registro_de_amin_acidos[i], registro_de_amin_acidos[j]);

                    // Para este loop.
                    break;
                }
            }

            // A tentativa falhou, cancele este loop.
            if (falhou == 1)
            {
                break;
            }
        }

        /**
         * Se os loops acima n�o acharam
         * uma falha, e n�o ocorreu erro
         * nenhum, ent�o deciframos o c�digo
         * gen�tico do nosso amino �cido.
         *
         * Ele est� no registro. � s� imprim�-lo.
         */
        if (falhou == 0)
        {
            printf("\nC�digo gen�tico decifrado!\n");
            printf("\nTotal de tentativas: %d\n", num_tentativas + 1);
            printf("C�digo gen�tico: ");

            for (int i = 0; i < qtd_amin_acidos; i++)
            {
                printf("%s", registro_de_amin_acidos[i]);
            }

            printf("\n");            

            break;
        }
    }

    /**
     * Se os loops acima terminaram o seu
     * �ltimo loop com uma tentativa falhada,
     * epah, fizemos tudo que estava ao nosso
     * alcanse... Mas n�o  foi poss�vel decifrar
     * o c�digo gen�tico da prote�na dada.
     */
    if (falhou == 1)
    {
        printf("\nN�o foi poss�vel decifrar o c�digo gen�tico da prote�na:\n\n%s\n\n na sequ�ncia gen�tica dada.\n\n", proteina);            
    }

    return 0;
}
