/**
 * Informa ao loop de tentativas
 * se pode continuar a tentar ou n�o.
 * 
 * O loop de tentivas pode continuar
 * a tentar se:
 * 
 * 1� O c�digo gen�tico ainda n�o foi decifrado.
 * 2� O n�mero de tentativas � menor que o n�mero
 * de nucleotides - a quantidade de amino �cidos.
 */
int da_pra_tentar(
    int cod_gen_decifrado,
    int num_tentativas,
    int qtd_nucleotides,
    int qtd_amin_acidos
) {
    return (cod_gen_decifrado == 0) && (num_tentativas < (qtd_nucleotides - qtd_amin_acidos));
}
