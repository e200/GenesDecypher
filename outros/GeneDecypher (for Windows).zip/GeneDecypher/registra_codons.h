#include "constantes.h"

/**
 * Pega a sequ�ncia dos genes
 * e associa a sua respectiva
 * prote�na.
 */

int registre_os_codons(
    /**
     * Onde a sequ�ncia de amino �cidos ser�
     * armazenada.
     */
    char registro_de_amin_acidos[][MAX_CODON],
    
    /**
     * Recebe a sequ�ncia de amino �cidos
     */
    char seq_amin_acid[],
    
    /**
     * Aqui recebe o n�mero de amino �cidos lidos.
     */
    int qtd_amin_acidos,
    
    /**
     * Recebe o n�mero de num_tentativas j� ocorridas
     * de decifrar o c�digo gen�tico da prote�na.
     */
    int num_tentativas
) {
    /**
     * Representa a posi��o do c�digo gen�tico
     * que estamos a ler.
     */
    int
        byte = num_tentativas,
        con_while = 0;

    for (int i = 0; i < qtd_amin_acidos; i++)
    {
        while (con_while != 3)
        {
            registro_de_amin_acidos[i][con_while] = seq_amin_acid[byte];

            byte++;

            con_while++;
        }

        con_while = 0;
    }

    return 0;
}
